
  # Literary Publication Website

  This is a code bundle for Literary Publication Website. The original project is available at https://www.figma.com/design/OElX1mYLXQnr0MZHh3VcMd/Literary-Publication-Website.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  
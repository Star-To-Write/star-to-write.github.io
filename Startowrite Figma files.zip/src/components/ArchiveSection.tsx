import { ImageWithFallback } from './figma/ImageWithFallback';
import { Button } from './ui/button';

const archiveItems = [
  {
    id: 1,
    title: "The Stranger",
    author: "Alex Rodriguez",
    category: "Short Fiction",
    excerpt: "A stranger gave you this mask and told you to take care of it. It is grotesque and looks ancient, but you notice...",
    image: "https://images.unsplash.com/photo-1567988122319-039d80fafc34?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx2aW50YWdlJTIwYm9va3MlMjBsaWJyYXJ5fGVufDF8fHx8MTc1NTYyNTgzOXww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    date: "December 2024"
  },
  {
    id: 2,
    title: "Digital Echoes",
    author: "Jordan Kim",
    category: "Poetry",
    excerpt: "In the silence between keystrokes, I find fragments of myself scattered across digital landscapes...",
    image: "https://images.unsplash.com/photo-1500381457785-20c97a29c78e?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtb2Rlcm4lMjBwb2V0cnklMjBib29rfGVufDF8fHx8MTc1NTcyODAyNXww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    date: "November 2024"
  },
  {
    id: 3,
    title: "The Last Letter",
    author: "Sam Chen",
    category: "Creative Nonfiction",
    excerpt: "I found my grandmother's letters hidden in her typewriter case, each word a bridge across decades...",
    image: "https://images.unsplash.com/photo-1727302788687-0c1fc737bd4d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx0eXBlNXJpdGVyJTIwd3JpdGluZyUyMHBhcGVyfGVufDF8fHx8MTc1NTcyODAyOHww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    date: "October 2024"
  }
];

export function ArchiveSection() {
  return (
    <div className="max-w-7xl mx-auto px-6 lg:px-12 py-16">
      <div className="mb-12">
        <h2 className="text-3xl mb-4 text-primary" style={{ fontFamily: 'Georgia, serif' }}>
          NEWEST PUBLISHED PIECES
        </h2>
        <p className="text-muted-foreground max-w-2xl" style={{ fontFamily: 'Inter, sans-serif' }}>
          Discover our latest publications from talented young writers, artists, and journalists.
        </p>
      </div>

      <div className="space-y-8">
        {archiveItems.map((item) => (
          <div
            key={item.id}
            className="group grid md:grid-cols-3 gap-8 bg-card/30 backdrop-blur-sm border border-border rounded-xl p-8 hover:border-primary/50 transition-all duration-300"
          >
            <div className="md:col-span-2">
              <div className="flex items-center gap-4 mb-4">
                <span className="text-xs tracking-wide text-primary uppercase" style={{ fontFamily: 'Inter, sans-serif' }}>
                  {item.category}
                </span>
                <span className="text-xs text-muted-foreground" style={{ fontFamily: 'Inter, sans-serif' }}>
                  {item.date}
                </span>
              </div>
              
              <h3 className="text-2xl mb-3 text-foreground group-hover:text-primary transition-colors" style={{ fontFamily: 'Georgia, serif' }}>
                {item.title}
              </h3>
              
              <p className="text-sm text-muted-foreground mb-4" style={{ fontFamily: 'Inter, sans-serif' }}>
                By {item.author}
              </p>
              
              <p className="text-muted-foreground leading-relaxed mb-6" style={{ fontFamily: 'Inter, sans-serif' }}>
                {item.excerpt}
              </p>
              
              <Button 
                variant="outline" 
                className="border-primary/50 text-primary hover:bg-primary hover:text-primary-foreground"
                style={{ fontFamily: 'Inter, sans-serif' }}
              >
                READ MORE →
              </Button>
            </div>
            
            <div className="relative">
              <div className="aspect-[4/5] rounded-lg overflow-hidden bg-gradient-to-br from-primary/10 to-transparent">
                <ImageWithFallback
                  src={item.image}
                  alt={item.title}
                  className="w-full h-full object-cover opacity-80 group-hover:opacity-100 transition-opacity duration-300"
                />
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
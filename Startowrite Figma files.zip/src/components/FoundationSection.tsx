import { Building2, Users, BookOpen, Star, ArrowRight } from 'lucide-react';
import { Button } from './ui/button';

interface FoundationSectionProps {
  onNavigate: (page: string) => void;
}

export function FoundationSection({ onNavigate }: FoundationSectionProps) {
  return (
    <div className="max-w-7xl mx-auto px-6 lg:px-12 py-16">
      <div className="relative bg-gradient-to-br from-card/50 via-card/40 to-card/30 backdrop-blur-sm border border-border rounded-3xl p-8 lg:p-12 overflow-hidden">
        {/* Decorative background elements */}
        <div className="absolute top-6 left-8 w-2 h-2 bg-primary/30 rounded-full animate-pulse"></div>
        <div className="absolute top-12 right-12 w-1 h-1 bg-primary/50 rounded-full animate-ping"></div>
        <div className="absolute bottom-8 left-12 w-1.5 h-1.5 bg-primary/40 rounded-full animate-pulse"></div>
        <div className="absolute bottom-16 right-16 w-1 h-1 bg-primary/60 rounded-full animate-ping" style={{ animationDelay: '1s' }}></div>
        
        <div className="relative z-10 text-center">
          {/* Header */}
          <div className="mb-8">
            <div className="text-xs tracking-widest text-primary uppercase mb-4" style={{ fontFamily: 'Inter, sans-serif' }}>
              INTRODUCING
            </div>
            
            <h2 className="text-3xl lg:text-4xl mb-6 text-primary" style={{ fontFamily: 'Georgia, serif' }}>
              Star to Write Foundation
            </h2>
            
            <div className="flex items-center justify-center gap-2 mb-6">
              <div className="h-px w-12 bg-gradient-to-r from-transparent to-primary/50"></div>
              <Star className="w-5 h-5 text-primary/70 fill-primary/30" />
              <div className="h-px w-12 bg-gradient-to-l from-transparent to-primary/50"></div>
            </div>
          </div>

          {/* Description */}
          <div className="max-w-4xl mx-auto mb-8">
            <p className="text-lg leading-relaxed text-foreground mb-6" style={{ fontFamily: 'Inter, sans-serif' }}>
              Beyond our literary platform, we're building bridges to connect you with organizations, resources, and opportunities 
              that can help you grow. From nonprofits to educational programs, from creative communities to professional development—
              we're here to help you find what you need to succeed.
            </p>
            
            <p className="text-primary italic text-lg" style={{ fontFamily: 'Georgia, serif' }}>
              Because sometimes the perfect opportunity is just one connection away.
            </p>
          </div>

          {/* Feature Cards */}
          <div className="grid md:grid-cols-3 gap-6 mb-8">
            {/* Discover Organizations */}
            <div className="bg-gradient-to-br from-primary/10 to-transparent rounded-xl p-6 border border-primary/20 hover:bg-primary/15 transition-all duration-300">
              <div className="w-12 h-12 bg-primary/20 rounded-full flex items-center justify-center mx-auto mb-4">
                <Building2 className="w-6 h-6 text-primary" />
              </div>
              <h3 className="text-lg mb-3 text-foreground" style={{ fontFamily: 'Georgia, serif' }}>
                Discover Organizations
              </h3>
              <p className="text-muted-foreground text-sm leading-relaxed" style={{ fontFamily: 'Inter, sans-serif' }}>
                Explore nonprofits, magazines, small businesses, and youth-led organizations making a difference
              </p>
            </div>

            {/* Find Resources */}
            <div className="bg-gradient-to-br from-primary/10 to-transparent rounded-xl p-6 border border-primary/20 hover:bg-primary/15 transition-all duration-300">
              <div className="w-12 h-12 bg-primary/20 rounded-full flex items-center justify-center mx-auto mb-4">
                <BookOpen className="w-6 h-6 text-primary" />
              </div>
              <h3 className="text-lg mb-3 text-foreground" style={{ fontFamily: 'Georgia, serif' }}>
                Find Resources
              </h3>
              <p className="text-muted-foreground text-sm leading-relaxed" style={{ fontFamily: 'Inter, sans-serif' }}>
                Access AP materials, school resources, STEM programs, and career opportunities tailored to your needs
              </p>
            </div>

            {/* Get Featured */}
            <div className="bg-gradient-to-br from-primary/10 to-transparent rounded-xl p-6 border border-primary/20 hover:bg-primary/15 transition-all duration-300">
              <div className="w-12 h-12 bg-primary/20 rounded-full flex items-center justify-center mx-auto mb-4">
                <Users className="w-6 h-6 text-primary" />
              </div>
              <h3 className="text-lg mb-3 text-foreground" style={{ fontFamily: 'Georgia, serif' }}>
                Get Featured
              </h3>
              <p className="text-muted-foreground text-sm leading-relaxed" style={{ fontFamily: 'Inter, sans-serif' }}>
                Showcase your organization and connect with our global community of young creators and leaders
              </p>
            </div>
          </div>

          {/* Call to Action */}
          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
            <Button 
              onClick={() => onNavigate('foundation')}
              className="bg-primary text-primary-foreground hover:bg-primary/90 px-8 py-3 group"
              style={{ fontFamily: 'Inter, sans-serif' }}
            >
              Explore Foundation
              <ArrowRight className="w-4 h-4 ml-2 group-hover:translate-x-1 transition-transform duration-200" />
            </Button>
            
            <p className="text-muted-foreground text-sm" style={{ fontFamily: 'Inter, sans-serif' }}>
              ✨ Connecting communities, empowering growth
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
import { useState } from "react";
import { Menu, X } from "lucide-react";
import { Button } from "./ui/button";

interface HeaderProps {
  currentPage: string;
  setCurrentPage: (page: string) => void;
}

export function Header({
  currentPage,
  setCurrentPage,
}: HeaderProps) {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const navItems = [
    { name: "Home", href: "home" },
    { name: "Submissions", href: "submissions" },
    { name: "Magazine", href: "magazine" },
    { name: "Art & Design", href: "gallery" },
    { name: "Journalism", href: "journalism" },
    { name: "Foundation", href: "foundation" },
    { name: "About", href: "about" },
    { name: "Contact", href: "contact" },
  ];

  const handleNavClick = (href: string) => {
    setCurrentPage(href);
    setIsMenuOpen(false);
  };

  return (
    <header className="relative z-50 py-6 px-6 lg:px-12">
      <div className="max-w-7xl mx-auto flex items-center justify-between">
        {/* Logo */}
        <div
          className="flex items-center cursor-pointer"
          onClick={() => setCurrentPage("home")}
        >
          <h1
            className="text-2xl text-primary"
            style={{ fontFamily: "Georgia, serif" }}
          >
            Star to{" "}
            <span className="text-foreground">Write</span>
          </h1>
        </div>

        {/* Desktop Navigation */}
        <nav className="hidden md:flex items-center space-x-8">
          {navItems.map((item) => (
            <button
              key={item.name}
              onClick={() => handleNavClick(item.href)}
              className={`text-sm font-medium transition-colors duration-200 ${
                currentPage === item.href
                  ? "text-primary"
                  : "text-foreground hover:text-primary"
              }`}
              style={{ fontFamily: "Inter, sans-serif" }}
            >
              {item.name}
            </button>
          ))}
        </nav>

        {/* Mobile Menu Button */}
        <Button
          variant="ghost"
          size="sm"
          className="md:hidden text-foreground hover:text-primary"
          onClick={() => setIsMenuOpen(!isMenuOpen)}
        >
          {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
        </Button>
      </div>

      {/* Mobile Navigation */}
      {isMenuOpen && (
        <div className="md:hidden absolute top-full left-0 right-0 bg-background/95 backdrop-blur-sm border-t border-border">
          <nav className="flex flex-col space-y-4 p-6">
            {navItems.map((item) => (
              <button
                key={item.name}
                onClick={() => handleNavClick(item.href)}
                className={`text-base font-medium transition-colors duration-200 text-left ${
                  currentPage === item.href
                    ? "text-primary"
                    : "text-foreground hover:text-primary"
                }`}
                style={{ fontFamily: "Inter, sans-serif" }}
              >
                {item.name}
              </button>
            ))}
          </nav>
        </div>
      )}
    </header>
  );
}
import { useState } from 'react';
import { Search, Filter, Mail, ExternalLink, Star, Building2, BookOpen, Users, Briefcase } from 'lucide-react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Badge } from './ui/badge';

interface FoundationPageProps {
  onNavigateHome: () => void;
}

interface Organization {
  id: number;
  name: string;
  description: string;
  category: string;
  website: string;
  logo: string;
  featured: boolean;
}

interface ResourceRequest {
  label: string;
  value: string;
}

const categories = [
  { id: 'all', name: 'All Organizations', icon: Star },
  { id: 'nonprofits', name: 'Nonprofits', icon: Building2 },
  { id: 'magazines', name: 'Magazines', icon: BookOpen },
  { id: 'small-businesses', name: 'Small Businesses', icon: Briefcase },
  { id: 'youth-led', name: 'Youth-led Organizations', icon: Users },
];

const resourceRequests: ResourceRequest[] = [
  { label: 'AP Resources', value: 'AP resources and study materials' },
  { label: 'School Resources', value: 'school resources and academic support' },
  { label: 'STEM Programs', value: 'STEM programs and opportunities' },
  { label: 'Medicine & Health', value: 'medicine and health-related resources' },
  { label: 'Read Other Magazines', value: 'recommendations for other literary magazines' },
  { label: 'Organizations Hiring', value: 'information about organizations that are hiring' },
];

// Mock data for organizations
const organizations: Organization[] = [
  {
    id: 1,
    name: 'Young Writers Foundation',
    description: 'Empowering youth through creative writing workshops and mentorship programs.',
    category: 'nonprofits',
    website: 'https://example.com',
    logo: '📝',
    featured: true,
  },
  {
    id: 2,
    name: 'Literary Horizons Magazine',
    description: 'A quarterly publication showcasing emerging voices in contemporary literature.',
    category: 'magazines',
    website: 'https://example.com',
    logo: '📖',
    featured: true,
  },
  {
    id: 3,
    name: 'Creative Minds Collective',
    description: 'A youth-led organization promoting artistic expression and community engagement.',
    category: 'youth-led',
    website: 'https://example.com',
    logo: '🎨',
    featured: true,
  },
  {
    id: 4,
    name: 'WordCraft Studio',
    description: 'A small business offering professional editing and publishing services.',
    category: 'small-businesses',
    website: 'https://example.com',
    logo: '✍️',
    featured: false,
  },
  {
    id: 5,
    name: 'Global Youth Voices',
    description: 'Connecting young writers and activists from around the world.',
    category: 'nonprofits',
    website: 'https://example.com',
    logo: '🌍',
    featured: true,
  },
  {
    id: 6,
    name: 'Tomorrow\'s Leaders Today',
    description: 'A youth-led initiative focusing on leadership development and social change.',
    category: 'youth-led',
    website: 'https://example.com',
    logo: '🚀',
    featured: false,
  },
];

export function FoundationPage({ onNavigateHome }: FoundationPageProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [showResourceDropdown, setShowResourceDropdown] = useState(false);

  const filteredOrganizations = organizations.filter(org => {
    const matchesSearch = org.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         org.description.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = selectedCategory === 'all' || org.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  const featuredOrganizations = filteredOrganizations.filter(org => org.featured);

  const handleResourceRequest = (value: string) => {
    const subject = `Request for more info about ${value}`;
    const body = `Hello Star to Write team,\n\nI am interested in learning more about ${value}. Could you please provide me with additional information or resources?\n\nThank you!\n\nBest regards,`;
    const mailtoLink = `mailto:startowrite@gmail.com?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
    window.location.href = mailtoLink;
    setShowResourceDropdown(false);
  };

  const handleOtherRequest = () => {
    const subject = 'Request for more info about ____';
    const body = `Hello Star to Write team,\n\nI am looking for information about: [Please specify what you're looking for]\n\nCould you please provide me with additional information or resources?\n\nThank you!\n\nBest regards,`;
    const mailtoLink = `mailto:startowrite@gmail.com?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
    window.location.href = mailtoLink;
    setShowResourceDropdown(false);
  };

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <div className="relative py-16 px-6 lg:px-12 bg-gradient-to-br from-card/40 via-card/30 to-transparent">
        <div className="max-w-6xl mx-auto text-center">
          {/* Decorative elements */}
          <div className="absolute top-8 left-8 w-2 h-2 bg-primary/30 rounded-full animate-pulse"></div>
          <div className="absolute top-12 right-12 w-1 h-1 bg-primary/50 rounded-full animate-ping"></div>
          <div className="absolute bottom-8 left-16 w-1.5 h-1.5 bg-primary/40 rounded-full animate-pulse"></div>
          
          <div className="relative z-10">
            <h1 className="text-5xl mb-6 text-primary" style={{ fontFamily: 'Georgia, serif' }}>
              Star to Write Foundation
            </h1>
            <div className="w-32 h-1 bg-primary mx-auto mb-8"></div>
            
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto leading-relaxed mb-6" style={{ fontFamily: 'Inter, sans-serif' }}>
              Connecting communities, empowering growth, and helping you discover the resources you need to shine.
            </p>
            
            <div className="bg-primary/10 border border-primary/30 rounded-xl p-6 max-w-4xl mx-auto">
              <p className="text-muted-foreground leading-relaxed" style={{ fontFamily: 'Inter, sans-serif' }}>
                Our foundation exists to feature and support organizations while helping individuals find resources 
                that Star to Write may not directly provide. We believe in the power of connection and collaboration 
                to create opportunities for everyone to grow and succeed.
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Search and Filters */}
      <div className="py-12 px-6 lg:px-12">
        <div className="max-w-6xl mx-auto">
          {/* Search Bar */}
          <div className="relative mb-8">
            <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 text-muted-foreground" size={20} />
            <Input
              type="text"
              placeholder="Search organizations, nonprofits, magazines..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-12 pr-4 py-3 text-lg bg-card/40 border-border rounded-xl"
              style={{ fontFamily: 'Inter, sans-serif' }}
            />
          </div>

          {/* Categories */}
          <div className="flex flex-wrap gap-3 mb-8">
            {categories.map((category) => {
              const IconComponent = category.icon;
              return (
                <Button
                  key={category.id}
                  variant={selectedCategory === category.id ? "default" : "outline"}
                  onClick={() => setSelectedCategory(category.id)}
                  className={`${
                    selectedCategory === category.id
                      ? 'bg-primary text-primary-foreground'
                      : 'border-primary/30 text-foreground hover:bg-primary/10'
                  } px-4 py-2 rounded-lg transition-all duration-200`}
                  style={{ fontFamily: 'Inter, sans-serif' }}
                >
                  <IconComponent size={16} className="mr-2" />
                  {category.name}
                </Button>
              );
            })}
          </div>

          {/* Action Buttons */}
          <div className="flex flex-col sm:flex-row gap-4 mb-12">
            <div className="relative">
              <Button
                onClick={() => setShowResourceDropdown(!showResourceDropdown)}
                className="bg-primary/20 text-primary border border-primary/30 hover:bg-primary/30 px-6 py-3"
                style={{ fontFamily: 'Inter, sans-serif' }}
              >
                <Mail size={16} className="mr-2" />
                Tell us what you're looking for
              </Button>
              
              {showResourceDropdown && (
                <div className="absolute top-full left-0 mt-2 w-80 bg-card/95 backdrop-blur-sm border border-border rounded-xl p-4 shadow-2xl z-50">
                  <h4 className="text-lg mb-3 text-primary" style={{ fontFamily: 'Georgia, serif' }}>
                    What are you looking for?
                  </h4>
                  <div className="space-y-2">
                    {resourceRequests.map((request) => (
                      <button
                        key={request.value}
                        onClick={() => handleResourceRequest(request.value)}
                        className="w-full text-left px-3 py-2 text-foreground hover:bg-primary/10 rounded-lg transition-colors"
                        style={{ fontFamily: 'Inter, sans-serif' }}
                      >
                        {request.label}
                      </button>
                    ))}
                    <button
                      onClick={handleOtherRequest}
                      className="w-full text-left px-3 py-2 text-primary hover:bg-primary/10 rounded-lg transition-colors"
                      style={{ fontFamily: 'Inter, sans-serif' }}
                    >
                      Other (specify in email)
                    </button>
                  </div>
                </div>
              )}
            </div>
            
            <Button
              className="bg-primary text-primary-foreground hover:bg-primary/90 px-6 py-3"
              style={{ fontFamily: 'Inter, sans-serif' }}
            >
              <Star size={16} className="mr-2" />
              Be Featured
            </Button>
          </div>

          {/* Featured Organizations */}
          {featuredOrganizations.length > 0 && (
            <div className="mb-12">
              <h2 className="text-2xl mb-6 text-primary" style={{ fontFamily: 'Georgia, serif' }}>
                Featured Organizations
              </h2>
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                {featuredOrganizations.map((org) => (
                  <div
                    key={org.id}
                    className="bg-card/40 backdrop-blur-sm border border-border rounded-xl p-6 hover:bg-card/60 transition-all duration-300 group"
                  >
                    <div className="flex items-start gap-4 mb-4">
                      <div className="text-4xl">{org.logo}</div>
                      <div className="flex-1">
                        <h3 className="text-lg text-foreground group-hover:text-primary transition-colors" style={{ fontFamily: 'Georgia, serif' }}>
                          {org.name}
                        </h3>
                        <Badge 
                          variant="outline" 
                          className="border-primary/30 text-primary/80 mt-2"
                        >
                          {categories.find(cat => cat.id === org.category)?.name}
                        </Badge>
                      </div>
                    </div>
                    
                    <p className="text-muted-foreground mb-4 leading-relaxed" style={{ fontFamily: 'Inter, sans-serif' }}>
                      {org.description}
                    </p>
                    
                    <Button
                      variant="outline"
                      size="sm"
                      className="border-primary/30 text-primary hover:bg-primary hover:text-primary-foreground w-full"
                      style={{ fontFamily: 'Inter, sans-serif' }}
                    >
                      <ExternalLink size={14} className="mr-2" />
                      Visit Website
                    </Button>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* All Organizations */}
          <div>
            <h2 className="text-2xl mb-6 text-primary" style={{ fontFamily: 'Georgia, serif' }}>
              All Organizations ({filteredOrganizations.length})
            </h2>
            
            {filteredOrganizations.length === 0 ? (
              <div className="text-center py-12">
                <div className="text-6xl mb-4">🔍</div>
                <h3 className="text-xl mb-2 text-muted-foreground" style={{ fontFamily: 'Georgia, serif' }}>
                  No organizations found
                </h3>
                <p className="text-muted-foreground" style={{ fontFamily: 'Inter, sans-serif' }}>
                  Try adjusting your search or category filter
                </p>
              </div>
            ) : (
              <div className="grid md:grid-cols-2 gap-6">
                {filteredOrganizations.map((org) => (
                  <div
                    key={org.id}
                    className="bg-card/30 backdrop-blur-sm border border-border rounded-xl p-6 hover:bg-card/50 transition-all duration-300 group"
                  >
                    <div className="flex items-start gap-4 mb-4">
                      <div className="text-3xl">{org.logo}</div>
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-2">
                          <h3 className="text-lg text-foreground group-hover:text-primary transition-colors" style={{ fontFamily: 'Georgia, serif' }}>
                            {org.name}
                          </h3>
                          {org.featured && (
                            <Star size={16} className="text-primary fill-primary" />
                          )}
                        </div>
                        <Badge 
                          variant="outline" 
                          className="border-primary/30 text-primary/80"
                        >
                          {categories.find(cat => cat.id === org.category)?.name}
                        </Badge>
                      </div>
                    </div>
                    
                    <p className="text-muted-foreground mb-4 leading-relaxed" style={{ fontFamily: 'Inter, sans-serif' }}>
                      {org.description}
                    </p>
                    
                    <Button
                      variant="outline"
                      size="sm"
                      className="border-primary/30 text-primary hover:bg-primary hover:text-primary-foreground"
                      style={{ fontFamily: 'Inter, sans-serif' }}
                    >
                      <ExternalLink size={14} className="mr-2" />
                      Learn More
                    </Button>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Call to Action */}
      <div className="py-16 px-6 lg:px-12 bg-gradient-to-br from-primary/5 to-transparent">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-2xl mb-6 text-primary" style={{ fontFamily: 'Georgia, serif' }}>
            Ready to Make a Difference?
          </h2>
          <p className="text-muted-foreground mb-8 leading-relaxed" style={{ fontFamily: 'Inter, sans-serif' }}>
            Whether you're looking for resources or want to be featured, we're here to help connect you with the right opportunities.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button 
              onClick={onNavigateHome}
              className="bg-primary text-primary-foreground hover:bg-primary/90 px-8 py-3"
              style={{ fontFamily: 'Inter, sans-serif' }}
            >
              Return Home
            </Button>
            <Button
              variant="outline"
              className="border-primary/30 text-primary hover:bg-primary hover:text-primary-foreground px-8 py-3"
              style={{ fontFamily: 'Inter, sans-serif' }}
            >
              Contact Us
            </Button>
          </div>
        </div>
      </div>

      {/* Click outside to close dropdown */}
      {showResourceDropdown && (
        <div 
          className="fixed inset-0 z-40"
          onClick={() => setShowResourceDropdown(false)}
        />
      )}
    </div>
  );
}
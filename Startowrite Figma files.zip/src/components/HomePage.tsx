import { NotificationBanner } from './NotificationBanner';
import { FeaturedArticle } from './FeaturedArticle';
import { CategoryGrid } from './CategoryGrid';
import { AboutUs } from './AboutUs';
import { FoundationSection } from './FoundationSection';
import { ArchiveSection } from './ArchiveSection';
import { StayWithUs } from './StayWithUs';

interface HomePageProps {
  onNavigate: (page: string) => void;
}

export function HomePage({ onNavigate }: HomePageProps) {
  return (
    <>
      {/* Breaking News Star */}
      <div className="fixed top-4 right-4 z-50">
        <div 
          onClick={() => onNavigate('get-published')}
          className="group cursor-pointer relative animate-pulse hover:animate-none transition-all duration-300"
        >
          <div className="relative">
            {/* Glowing effect */}
            <div className="absolute inset-0 bg-primary/30 rounded-full blur-md animate-pulse"></div>
            
            {/* Star shape */}
            <div className="relative w-16 h-16 flex items-center justify-center">
              <svg 
                className="w-14 h-14 text-primary drop-shadow-lg group-hover:scale-110 transition-transform duration-300" 
                fill="currentColor" 
                viewBox="0 0 24 24"
              >
                <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/>
              </svg>
              
              {/* Text overlay */}
              <div className="absolute inset-0 flex flex-col items-center justify-center text-center">
                <span className="text-xs text-background leading-none" style={{ fontFamily: 'Inter, sans-serif', fontWeight: '700' }}>
                  STAR
                </span>
                <span className="text-xs text-background leading-none" style={{ fontFamily: 'Inter, sans-serif', fontWeight: '700' }}>
                  TO
                </span>
                <span className="text-xs text-background leading-none" style={{ fontFamily: 'Inter, sans-serif', fontWeight: '700' }}>
                  WRITE
                </span>
              </div>
            </div>
            
            {/* Breaking news text */}
            <div className="absolute -bottom-8 left-1/2 transform -translate-x-1/2 whitespace-nowrap">
              <span className="text-xs text-primary bg-background/80 px-2 py-1 rounded-full border border-primary/30" style={{ fontFamily: 'Inter, sans-serif', fontWeight: '500' }}>
                BREAKING NEWS
              </span>
            </div>
          </div>
        </div>
      </div>

      <NotificationBanner />
      <FeaturedArticle />
      <CategoryGrid onNavigate={onNavigate} />
      <AboutUs />
      <FoundationSection onNavigate={onNavigate} />
      <ArchiveSection />
      <StayWithUs onNavigateHome={() => onNavigate('home')} />
    </>
  );
}
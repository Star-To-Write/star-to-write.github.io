import { Instagram, Mail, Play } from 'lucide-react';

interface FooterProps {
  onNavigate?: (page: string) => void;
}

export function Footer({ onNavigate }: FooterProps) {
  const socialLinks = [
    { icon: Instagram, href: 'https://www.instagram.com/startowrite/', label: 'Instagram' },
    { icon: Play, href: 'https://www.tiktok.com/@startowrite', label: 'TikTok' },
    { icon: Mail, href: 'mailto:startowrite@gmail.com', label: 'Email' }
  ];

  const footerLinks = [
    { name: 'Privacy Policy', onClick: () => onNavigate?.('privacy-policy') },
    { name: 'Contact', onClick: () => onNavigate?.('contact') },
    { name: 'Submissions', onClick: () => onNavigate?.('submissions') },
    { name: 'About', onClick: () => onNavigate?.('about') }
  ];

  return (
    <footer className="border-t border-border mt-20">
      <div className="max-w-7xl mx-auto px-6 lg:px-12 py-12">
        <div className="flex flex-col items-center space-y-8">
          {/* Logo */}
          <div className="text-center">
            <h3 className="text-xl text-primary mb-2" style={{ fontFamily: 'Georgia, serif' }}>
              Star to <span className="text-foreground">Write</span>
            </h3>
            <p className="text-sm text-muted-foreground max-w-md" style={{ fontFamily: 'Inter, sans-serif' }}>
              A literary publication celebrating the voices of young writers, artists, and journalists.
            </p>
          </div>

          {/* Social Links */}
          <div className="flex items-center space-x-6">
            {socialLinks.map((social) => {
              const Icon = social.icon;
              return (
                <a
                  key={social.label}
                  href={social.href}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-muted-foreground hover:text-primary transition-colors duration-200"
                  aria-label={social.label}
                >
                  <Icon size={20} />
                </a>
              );
            })}
          </div>

          {/* Footer Links */}
          <div className="flex flex-wrap items-center justify-center gap-6">
            {footerLinks.map((link) => (
              <button
                key={link.name}
                onClick={link.onClick}
                className="text-sm text-muted-foreground hover:text-primary transition-colors duration-200"
                style={{ fontFamily: 'Inter, sans-serif' }}
              >
                {link.name}
              </button>
            ))}
          </div>

          {/* Copyright */}
          <div className="text-center border-t border-border pt-8 w-full">
            <p className="text-xs text-muted-foreground" style={{ fontFamily: 'Inter, sans-serif' }}>
              © 2024 Star to Write. All rights reserved. Empowering young voices since 2024.
            </p>
          </div>
        </div>
      </div>
    </footer>
  );
}